﻿using AdquisicionesAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace AdquisicionesAPI.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }
        public DbSet<Adquisicion> Adquisiciones { get; set; }
        public DbSet<HistorialAdquisiciones> HistorialAdquisiciones { get; set; }
    }
}


