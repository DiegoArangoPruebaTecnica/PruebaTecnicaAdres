﻿using AdquisicionesAPI.Data;
using AdquisicionesAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AdquisicionesAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdquisicionController : ControllerBase
    {
        private readonly AppDbContext _context;

        public AdquisicionController(AppDbContext context)
        {
            _context = context;
        }

        // Obtener todas las adquisiciones
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Adquisicion>>> GetAdquisiciones()
        {
            return await _context.Adquisiciones.ToListAsync();
        }

        // Obtener una adquisición por ID
        [HttpGet("{id}")]
        public async Task<ActionResult<Adquisicion>> GetAdquisicion(int id)
        {
            var adquisicion = await _context.Adquisiciones.FindAsync(id);

            if (adquisicion == null)
            {
                return NotFound(new { mensaje = "Adquisición no encontrada" });
            }

            return adquisicion;
        }

        // Crear una nueva adquisición
        [HttpPost]
        public async Task<ActionResult<Adquisicion>> PostAdquisicion(Adquisicion adquisicion)
        {
            if (adquisicion == null)
            {
                return BadRequest(new { mensaje = "Los datos de la adquisición son inválidos" });
            }

            _context.Adquisiciones.Add(adquisicion);
            await _context.SaveChangesAsync();

           
            //Crea el historial de la insercion
            var historial = new HistorialAdquisiciones
            {
                AdquisicionId = adquisicion.Id,
                TipoBienServicio = adquisicion.TipoBienServicio,
                Proveedor = adquisicion.Proveedor,
                Presupuesto = adquisicion.Presupuesto,
                Unidad = adquisicion.Unidad,
                Cantidad = adquisicion.Cantidad,
                ValorUnitario = adquisicion.ValorUnitario,
                ValorTotal = adquisicion.ValorTotal,
                FechaAdquisicion = adquisicion.FechaAdquisicion,
                Documentacion = adquisicion.Documentacion,
                Accion = "Insertar"
            };

            _context.HistorialAdquisiciones.Add(historial);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetAdquisicion), new { id = adquisicion.Id }, adquisicion);

        }
        //Crea una modificacion a una adquisicion
        [HttpPut("{id}")]
        public async Task<IActionResult> PutAdquisicion(int id, [FromBody] Adquisicion adquisicion)
        {
            if (id != adquisicion.Id)
            {
                return BadRequest();
            }

            _context.Entry(adquisicion).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();

                // Crea el historial de la modificacion
                var historial = new HistorialAdquisiciones
                {
                    AdquisicionId = adquisicion.Id,
                    TipoBienServicio = adquisicion.TipoBienServicio,
                    Proveedor = adquisicion.Proveedor,
                    Presupuesto = adquisicion.Presupuesto,
                    Unidad = adquisicion.Unidad,
                    Cantidad = adquisicion.Cantidad,
                    ValorUnitario = adquisicion.ValorUnitario,
                    ValorTotal = adquisicion.ValorTotal,
                    FechaAdquisicion = adquisicion.FechaAdquisicion,
                    Documentacion = adquisicion.Documentacion,
                    Accion = "Modificar"
                };

                _context.HistorialAdquisiciones.Add(historial);
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!_context.Adquisiciones.Any(e => e.Id == id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }
        //Elimina una adquisicion
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteAdquisicion(int id)
        {
            var adquisicion = await _context.Adquisiciones.FindAsync(id);
            if (adquisicion == null)
            {
                return NotFound();
            }

            // Crea el historial de la eliminacion de una adquisicion
            var historial = new HistorialAdquisiciones
            {
                AdquisicionId = adquisicion.Id,
                TipoBienServicio = adquisicion.TipoBienServicio,
                Proveedor = adquisicion.Proveedor,
                Presupuesto = adquisicion.Presupuesto,
                Unidad = adquisicion.Unidad,
                Cantidad = adquisicion.Cantidad,
                ValorUnitario = adquisicion.ValorUnitario,
                ValorTotal = adquisicion.ValorTotal,
                FechaAdquisicion = adquisicion.FechaAdquisicion,
                Documentacion = adquisicion.Documentacion,
                Accion = "Eliminar"
            };

            _context.HistorialAdquisiciones.Add(historial);
            await _context.SaveChangesAsync();

            _context.Adquisiciones.Remove(adquisicion);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        //Obtiene el todo el historial de las adquisiciones 
        [HttpGet("historial")]
        public async Task<ActionResult<IEnumerable<HistorialAdquisiciones>>> GetHistorial()
        {
            return await _context.HistorialAdquisiciones.ToListAsync();
        }


    }
}
