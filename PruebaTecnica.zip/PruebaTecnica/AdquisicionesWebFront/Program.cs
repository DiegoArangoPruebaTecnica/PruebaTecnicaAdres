var builder = WebApplication.CreateBuilder(args);

var app = builder.Build();

// Configurar el pipeline de solicitudes HTTP
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles(); // Habilitar archivos est�ticos desde wwwroot

app.UseRouting();

// Configurar el archivo de inicio predeterminado (index.html)
app.UseDefaultFiles(); // Busca autom�ticamente index.html, index.htm, etc.
app.UseStaticFiles();  // Habilita la carga de archivos est�ticos

app.Run();
