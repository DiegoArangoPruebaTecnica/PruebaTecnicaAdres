﻿document.addEventListener("DOMContentLoaded", function () {
   
    document.getElementById("btnVolver").addEventListener("click", function () {
        window.location.href = "index.html"; 
    });
    cargarHistorial();
});

//Consume el servicio y carga todo el historial de las adquisiciones 
function cargarHistorial() {
    fetch("https://localhost:7138/api/Adquisicion/historial")
        .then(response => response.json())
        .then(data => mostrarHistorial(data))
        .catch(error => console.error("Error al cargar historial:", error));
}
//Carga los resultados del historial en la tabla de resultados
function mostrarHistorial(historial) {
    const tablaHistorial = document.getElementById("tablaHistorial");
    tablaHistorial.innerHTML = "";

    historial.forEach(item => {
        const fila = document.createElement("tr");
        fila.innerHTML = `
            <td>${item.id}</td>
            <td>${item.adquisicionId}</td>
            <td>${item.tipoBienServicio}</td>
            <td>${item.proveedor}</td>
            <td>${item.presupuesto.toLocaleString("es-CO", { style: "currency", currency: "COP" })}</td>
            <td>${item.unidad}</td>
            <td>${item.cantidad}</td>
            <td>${item.valorUnitario.toLocaleString("es-CO", { style: "currency", currency: "COP" })}</td>
            <td>${item.valorTotal.toLocaleString("es-CO", { style: "currency", currency: "COP" })}</td>
            <td>${new Date(item.fechaAdquisicion).toLocaleDateString()}</td>
            <td>${item.accion}</td>
            <td>${new Date(item.fechaAccion).toLocaleDateString()}</td>
        `;
        tablaHistorial.appendChild(fila);
    });
}
