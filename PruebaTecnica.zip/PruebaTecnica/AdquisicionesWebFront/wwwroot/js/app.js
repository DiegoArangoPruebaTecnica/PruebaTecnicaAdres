﻿const apiUrl = "https://localhost:7138/api/Adquisicion";

document.addEventListener("DOMContentLoaded", function () {
    const botonAgregar = document.getElementById("agregarBtn");

    if (botonAgregar) {
        botonAgregar.addEventListener("click", function () {
            agregarAdquisicion();
        });
    } else {
        console.error("No se encontró el botón Agregar");
    }
    document.getElementById("btnFiltrar").addEventListener("click", filtrarAdquisiciones);
    document.getElementById("btnLimpiarFiltros").addEventListener("click", limpiarFiltros);
    cargarAdquisiciones();

   
    
});
//Todas las adquisiciones por defecto
function cargarAdquisiciones() {
    fetch(apiUrl)
        .then(response => {
            if (!response.ok) {
                throw new Error("Error al obtener adquisiciones");
            }
            return response.json();
        })
        .then(data => {
            mostrarAdquisiciones(data);
        })
        .catch(error => console.error("Error al cargar adquisiciones:", error));
}
// Carga las adquisiciones que cumplen con los filtros realizados
function mostrarAdquisiciones(adquisiciones) {
    const tabla = document.getElementById("tablaAdquisiciones");
    tabla.innerHTML = ""; // Limpiar la tabla antes de agregar los nuevos datos

    if (adquisiciones.length === 0) {
        // Si no hay resultados, mostrar una fila con el mensaje "Sin resultados"
        const fila = document.createElement("tr");
        fila.innerHTML = `<td colspan="11" class="sin-resultados">Sin resultados</td>`;
        tabla.appendChild(fila);
        return;
    }

    adquisiciones.forEach(adq => {
        const fila = document.createElement("tr");
        fila.innerHTML = `
            <td>${adq.id}</td>
            <td>${adq.tipoBienServicio}</td>
            <td>${adq.proveedor}</td>
             <td>${adq.presupuesto.toLocaleString("es-CO", { style: "currency", currency: "COP" })}</td>
            <td>${adq.unidad}</td>
            <td>${adq.cantidad}</td>
            <td>${adq.valorUnitario.toLocaleString("es-CO", { style: "currency", currency: "COP" })}</td>
            <td>${adq.valorTotal.toLocaleString("es-CO", { style: "currency", currency: "COP" })}</td>
            <td>${new Date(adq.fechaAdquisicion).toLocaleDateString()}</td>
            <td>${adq.documentacion}</td>
            <td>
                <button class="btn-modificar" onclick="modificarAdquisicion(${adq.id})">Modificar</button>
                <button class="btn-eliminar" onclick="eliminarAdquisicion(${adq.id})">Eliminar</button>
            </td>
        `;
        tabla.appendChild(fila);
    });
}
//Consume el servicio de guardado de adquisiciones
function agregarAdquisicion() {
    if (!validarFormulario()) return;
    const nuevoAdq = {
        tipoBienServicio: document.getElementById("tipoBien").value,
        proveedor: document.getElementById("proveedor").value,
        presupuesto: parseFloat(document.getElementById("presupuesto").value),
        unidad: document.getElementById("unidad").value,
        cantidad: parseInt(document.getElementById("cantidad").value),
        valorUnitario: parseFloat(document.getElementById("valorUnitario").value),
        fechaAdquisicion: document.getElementById("fechaAdquisicion").value,
        documentacion: document.getElementById("documentacion").value
    };

    fetch(apiUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(nuevoAdq)
    })
        .then(response => {
            if (!response.ok) {
                throw new Error("Error al agregar adquisición");
            }
            return response.json();
        })
        .then(() => {
            alert("Adquisición agregada correctamente");
            location.reload();
        })
        .catch(error => console.error("Error al agregar adquisición:", error));
}
//Consume el servicio para eliminar la adquisicion con el id que pasa por parametro
function eliminarAdquisicion(id) {
    fetch(`${apiUrl}/${id}`, {
        method: "DELETE"
    })
        .then(response => {
            if (!response.ok) {
                throw new Error("Error al eliminar adquisición");
            }
        })
        .then(() => {
            alert("Adquisición eliminada correctamente");
            location.reload(); 
        })
        .catch(error => console.error("Error al eliminar adquisición:", error));
}
//Consume el servicio para modificar la adquisicion con el id que pasa por parametro
function modificarAdquisicion(id) {
    fetch(`${apiUrl}/${id}`)
        .then(response => response.json())
        .then(adq => {
            const nuevoTipo = prompt("Ingrese el nuevo tipo de bien/servicio:", adq.tipoBienServicio);
            const nuevoProveedor = prompt("Ingrese el nuevo proveedor:", adq.proveedor);
            const nuevoPresupuesto = prompt("Ingrese el nuevo presupuesto:", adq.presupuesto);
            const nuevaUnidad = prompt("Ingrese la nueva unidad:", adq.unidad);
            const nuevaCantidad = prompt("Ingrese la nueva cantidad:", adq.cantidad);
            const nuevoValorUnitario = prompt("Ingrese el nuevo valor unitario:", adq.valorUnitario);
            const nuevaFecha = prompt("Ingrese la nueva fecha de adquisición:", adq.fechaAdquisicion);
            const nuevaDocumentacion = prompt("Ingrese la nueva documentación:", adq.documentacion);

            const adquisicionActualizada = {
                id: adq.id,
                tipoBienServicio: nuevoTipo,
                proveedor: nuevoProveedor,
                presupuesto: parseFloat(nuevoPresupuesto),
                unidad: nuevaUnidad,
                cantidad: parseInt(nuevaCantidad),
                valorUnitario: parseFloat(nuevoValorUnitario),
                valorTotal: parseFloat(nuevaCantidad) * parseFloat(nuevoValorUnitario),
                fechaAdquisicion: nuevaFecha,
                documentacion: nuevaDocumentacion
            };

            return fetch(`${apiUrl}/${id}`, {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(adquisicionActualizada)
            });
        })
        .then(response => {
            if (!response.ok) {
                throw new Error("Error al modificar adquisición");
            }
            alert("Adquisición modificada correctamente");
            location.reload(); 
        })
        .catch(error => console.error("Error al modificar adquisición:", error));
}

//Validacion de los campos del formulario
function validarFormulario() {
    let esValido = true;
    let mensajeError = "Por favor, complete los siguientes campos:\n";

    const campos = [
        { id: "tipoBien", nombre: "Tipo de Bien o Servicio" },
        { id: "proveedor", nombre: "Proveedor" },
        { id: "presupuesto", nombre: "Presupuesto" },
        { id: "unidad", nombre: "Unidad" },
        { id: "cantidad", nombre: "Cantidad" },
        { id: "valorUnitario", nombre: "Valor Unitario" },
        { id: "fechaAdquisicion", nombre: "Fecha de Adquisición" }
    ];

    campos.forEach(campo => {
        const input = document.getElementById(campo.id);
        if (input.value.trim() === "") {
            esValido = false;
            mensajeError += `- ${campo.nombre}\n`;
            input.style.border = "2px solid red"; 
        } else {
            input.style.border = "1px solid #ccc"; 
        }
    });

    if (!esValido) {
        alert(mensajeError); 
    }

    return esValido;
}

//Filtrado de las adquisiciones obtenidas mediante el consumo del servicio
//cargando solo las aquisiciones que cumplen con los filtros ingresados
function filtrarAdquisiciones() {
    
    const tipoBien = document.getElementById("filtroTipoBien").value.toLowerCase();
    const proveedor = document.getElementById("filtroProveedor").value.toLowerCase();
    const fechaInicio = document.getElementById("filtroFechaInicio").value;
    const fechaFin = document.getElementById("filtroFechaFin").value;

    fetch("https://localhost:7138/api/Adquisicion")
        .then(response => response.json())
        .then(data => {
            let adquisicionesFiltradas = data;

            // Filtrar por Tipo de Bien/Servicio
            if (tipoBien) {
                adquisicionesFiltradas = adquisicionesFiltradas.filter(adq =>
                    adq.tipoBienServicio.toLowerCase().includes(tipoBien)
                );
            }

            // Filtrar por Proveedor
            if (proveedor) {
                adquisicionesFiltradas = adquisicionesFiltradas.filter(adq =>
                    adq.proveedor.toLowerCase().includes(proveedor)
                );
            }

            // Filtrar por Rango de Fechas
            if (fechaInicio) {
                adquisicionesFiltradas = adquisicionesFiltradas.filter(adq =>
                    new Date(adq.fechaAdquisicion) >= new Date(fechaInicio)
                );
            }

            if (fechaFin) {
                adquisicionesFiltradas = adquisicionesFiltradas.filter(adq =>
                    new Date(adq.fechaAdquisicion) <= new Date(fechaFin)
                );
            }

            mostrarAdquisiciones(adquisicionesFiltradas);
        })
        .catch(error => console.error("Error al cargar adquisiciones:", error));
}
//Restablece los los campos de los filtros
function limpiarFiltros() {
    document.getElementById("filtroTipoBien").value = "";
    document.getElementById("filtroProveedor").value = "";
    document.getElementById("filtroFechaInicio").value = "";
    document.getElementById("filtroFechaFin").value = "";

    cargarAdquisiciones(); 
}